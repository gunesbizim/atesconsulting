<footer>
    <div class="container">
        <p>© 2022. Ates Consulting, All rights reserved.</p>
    </div>
</footer>



<script src="{{ asset('assets/frontend/lib/js/jquery-3.5.1.min.js') }}"></script>
<script src="{{ asset('assets/frontend/lib/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/frontend/lib/js/owl.carousel.js') }}"></script>

<script src="{{ asset('assets/frontend/js/master.js') }}"></script>


<script>

// $('#bannerformsubmit').click(function () {
//     console.log('clicked');
//     event.preventDefault();
//     var formValues= $(this).serialize();

//         $.ajax({
//             contentType: "application/json",
//             type: "POST",
//             data: JSON.stringify(formValues),
//             success: function (response) {
//                 if (response.status === true) {
//                     window.location.href = '/form-tamamlandi';
//                 }
//             },
//             error: function (error) {
//                 console.log(error);
//             }
//         });
// });
</script>
