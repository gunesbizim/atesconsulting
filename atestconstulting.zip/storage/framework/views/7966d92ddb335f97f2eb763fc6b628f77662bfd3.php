
<style>
    .mail-container{
        margin: 5%;
        width: 100%;
        display: flex;
        flex-direction: column!important;
        justify-content: center;
        align-items: center;
    }

    .mail-container > div.image{
        width: 100%;
    }

    .mail-container > div.content{
        display: flex;
        justify-content: center;
        /* align-items: center; */
    }
</style>

<div class="mail-container"
        style="width:100%;flex-direction:column!important;justify-content:center;align-items:center;"
    >
    <div class="image"
            style="width:100vh;display:flex;justify-content:center;"
            >
        <img src="<?php echo e(asset('assets/frontend/img/ates_logo.png')); ?>" alt=""
                style="max-height: 20vh;">

    </div>

    <div class="content"
            style="" >
        <h3 style="">
            Contact Form Submitted
        </h3>

        <ul>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <span
                        style="font-weight: 600;">
                        <?php echo e($key); ?>

                    </span> <?php echo e($value); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH /var/www/atesconsulting/resources/views/emails/contact.blade.php ENDPATH**/ ?>