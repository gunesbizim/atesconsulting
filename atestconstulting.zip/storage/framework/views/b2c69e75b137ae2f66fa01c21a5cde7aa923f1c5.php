
<style>
    .mail-container{
        width: 100%;
        max-width: 600px;
        display: block;
        margin: 100px auto 0;
    }

    .mail-container > div.image{
        width: 100%;
    }

    .mail-container > div.content{

        justify-content: center;
        /* align-items: center; */
    }
</style>

<div class="mail-container"
        style="width: 100%;max-width: 600px;display: block;margin: 100px auto 0;"
    >
    <div class="image" style="width:100vh;">
        <img src="<?php echo e(asset('assets/frontend/img/ates_logo.png')); ?>" alt="" style="max-height: 20vh;display: block; margin:0 auto;">
    </div>

    <div class="content"style="text-align: center;" >
        <h3 style="">
            Thank you for contacting us, we will get back to you soon.
        </h3>
        <p style="font-size: 24px; font-weight:bold;">
            Ates Consulting
        </p>

    </div>
</div>
<?php /**PATH /var/www/vhosts/atesconsulting.com/httpdocs/resources/views/emails/submit.blade.php ENDPATH**/ ?>