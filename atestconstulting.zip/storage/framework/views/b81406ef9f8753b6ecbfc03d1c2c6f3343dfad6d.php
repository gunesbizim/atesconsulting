<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="ScreenOrientation" content="autoRotate:disabled">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>
    <?php
        if (isset($title)){
            echo $title. ' | Ateş Consulting';
        }else{
            echo 'Ateş Consulting';
        }
    ?>
</title>
<meta name="description" content="<?php echo e($metadesc ?? ''); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lib/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lib/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lib/css/owl.theme.default.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/mobile.css')); ?>">
<?php /**PATH /var/www/atesconsulting/resources/views/layouts/head.blade.php ENDPATH**/ ?>