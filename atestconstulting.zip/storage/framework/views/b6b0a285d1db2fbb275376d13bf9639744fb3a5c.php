<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="ScreenOrientation" content="autoRotate:disabled">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>Ates Consulting | Your Gateway to Europe.</title>
<meta name="description" content="We are specialized in advising companies with expanding business operations, international transactions as well as localization and market entry objectives.">

<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lib/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lib/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lib/css/owl.theme.default.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/mobile.css')); ?>">
<?php /**PATH /var/www/vhosts/atesconsulting.com/httpdocs/resources/views/layouts/head.blade.php ENDPATH**/ ?>