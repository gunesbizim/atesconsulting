<?php $__env->startSection('content'); ?>

<section id="page">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <img src="<?php echo e(asset('assets/frontend/img/success.svg')); ?>" alt="" class="img-fluid successImage">
                <h1 class="pageTitle">SUCCESS</h1>
                <p class="pageText">
                     Your request has been received. <br>We will get back to you as soon as possible!
                </p>
                <a href="/" class="btn btnAtesAlt">Home Page</a>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master',[
    'title' => 'Ateş Consulting',
    'metadesc' => 'Meta Açıklama'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/atesconsulting/resources/views/frontend/success.blade.php ENDPATH**/ ?>